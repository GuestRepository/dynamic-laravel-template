-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2022 at 04:25 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_ssmv`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `id` int(11) NOT NULL,
  `department` varchar(25) NOT NULL,
  `stream_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `strength` int(11) DEFAULT NULL,
  `success_rate` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notice`
--

CREATE TABLE `tbl_notice` (
  `id` int(11) NOT NULL,
  `notice_type_id` smallint(6) DEFAULT NULL,
  `notice_body` text DEFAULT NULL,
  `notice_content` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notice_type`
--

CREATE TABLE `tbl_notice_type` (
  `id` smallint(6) NOT NULL,
  `type` varchar(10) NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_organisation`
--

CREATE TABLE `tbl_organisation` (
  `id` int(11) NOT NULL,
  `org_name` varchar(50) NOT NULL,
  `org_address` varchar(255) NOT NULL,
  `org_pinCode` int(11) NOT NULL,
  `org_email` varchar(50) DEFAULT NULL,
  `org_phone` varchar(10) DEFAULT NULL,
  `org_establishment_year` year(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `org_short_name` varchar(5) DEFAULT NULL,
  `org_contact` varchar(12) DEFAULT NULL,
  `org_logo` varchar(255) DEFAULT NULL,
  `accredited` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_organisation`
--

INSERT INTO `tbl_organisation` (`id`, `org_name`, `org_address`, `org_pinCode`, `org_email`, `org_phone`, `org_establishment_year`, `created_at`, `updated_at`, `org_short_name`, `org_contact`, `org_logo`, `accredited`) VALUES
(1, 'product', 'mumbai', 852154, 'test@gmail.com', '8754214587', 2022, '2022-06-13 13:14:25', '2022-06-13 13:14:25', 'pdt', '8754985632', NULL, 'nacc');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_principals`
--

CREATE TABLE `tbl_principals` (
  `id` smallint(6) NOT NULL,
  `name` varchar(100) NOT NULL,
  `department` varchar(50) NOT NULL,
  `service_from` date NOT NULL,
  `service_to` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ord_id` int(11) DEFAULT NULL,
  `qualification` varchar(25) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rules`
--

CREATE TABLE `tbl_rules` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `content` text DEFAULT NULL,
  `ord_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stream`
--

CREATE TABLE `tbl_stream` (
  `id` int(11) NOT NULL,
  `stream` varchar(25) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `organisation_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_testimonial`
--

CREATE TABLE `tbl_testimonial` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `imaage` varchar(100) DEFAULT NULL,
  `department_id` int(11) NOT NULL,
  `contact` varchar(10) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `designation` varchar(25) DEFAULT NULL,
  `company` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `department` (`department`,`stream_id`),
  ADD KEY `stream_id` (`stream_id`);

--
-- Indexes for table `tbl_notice`
--
ALTER TABLE `tbl_notice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notice_type_id` (`notice_type_id`);

--
-- Indexes for table `tbl_notice_type`
--
ALTER TABLE `tbl_notice_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `org_id` (`org_id`);

--
-- Indexes for table `tbl_organisation`
--
ALTER TABLE `tbl_organisation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `org_contact` (`org_phone`),
  ADD UNIQUE KEY `org_email` (`org_email`),
  ADD UNIQUE KEY `org_short_name` (`org_short_name`);

--
-- Indexes for table `tbl_principals`
--
ALTER TABLE `tbl_principals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ord_id` (`ord_id`);

--
-- Indexes for table `tbl_rules`
--
ALTER TABLE `tbl_rules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `ord_id` (`ord_id`);

--
-- Indexes for table `tbl_stream`
--
ALTER TABLE `tbl_stream`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `stream` (`stream`),
  ADD KEY `organisation_id` (`organisation_id`);

--
-- Indexes for table `tbl_testimonial`
--
ALTER TABLE `tbl_testimonial`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contact` (`contact`),
  ADD KEY `department_id` (`department_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_notice`
--
ALTER TABLE `tbl_notice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_notice_type`
--
ALTER TABLE `tbl_notice_type`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_organisation`
--
ALTER TABLE `tbl_organisation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_principals`
--
ALTER TABLE `tbl_principals`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_rules`
--
ALTER TABLE `tbl_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_stream`
--
ALTER TABLE `tbl_stream`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_testimonial`
--
ALTER TABLE `tbl_testimonial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD CONSTRAINT `tbl_department_ibfk_1` FOREIGN KEY (`stream_id`) REFERENCES `tbl_stream` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_notice`
--
ALTER TABLE `tbl_notice`
  ADD CONSTRAINT `tbl_notice_ibfk_1` FOREIGN KEY (`notice_type_id`) REFERENCES `tbl_notice_type` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_notice_type`
--
ALTER TABLE `tbl_notice_type`
  ADD CONSTRAINT `tbl_notice_type_ibfk_1` FOREIGN KEY (`org_id`) REFERENCES `tbl_organisation` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_principals`
--
ALTER TABLE `tbl_principals`
  ADD CONSTRAINT `tbl_principals_ibfk_1` FOREIGN KEY (`ord_id`) REFERENCES `tbl_organisation` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_rules`
--
ALTER TABLE `tbl_rules`
  ADD CONSTRAINT `tbl_rules_ibfk_1` FOREIGN KEY (`ord_id`) REFERENCES `tbl_organisation` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_stream`
--
ALTER TABLE `tbl_stream`
  ADD CONSTRAINT `tbl_stream_ibfk_1` FOREIGN KEY (`organisation_id`) REFERENCES `tbl_organisation` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `tbl_testimonial`
--
ALTER TABLE `tbl_testimonial`
  ADD CONSTRAINT `tbl_testimonial_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `tbl_department` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
