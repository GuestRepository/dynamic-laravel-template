@extends("layout.master")
@section("content")
    @include("shared.breadcrumbs")
    @include("shared.department")
@endsection
