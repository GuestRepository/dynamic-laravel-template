@extends("layout.master")
@section('content')
   @include("shared.breadcrumbs")

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">

            <div class="row content">
                <div class="col-lg-6">
                    <h2>A  Brief  History</h2>
                    <h3>
                        College is a distinct mile stone in the field of Higher Education. It
                        aims at developing self-awareness, academic excellence & global perspective in the beings and
                        becomings of the students. It has a philosophy which promotes complete development of a student as a responsible individual & citizen. In this connection, it is rightly said that “Education always grooms the students for the greater wars of life & to enable them to stand in a good stead in future.”
                    </h3>
                </div>
                <div class="col-lg-6 pt-4 pt-lg-0">
                    <p>
                        To make this indelible thought fruitful, the institute “Saraswata Snataka   (Degree) Mahavidyalaya” came into existence in a forest abounding tribal & sub-plan region called “Kuamara” in the district of Mayurbhanj in the session 1990 with a permitted seat strength of 128 & as the 1st degree college of the block i.e., Gopabandhu Nagar Block. Since its inception, it has aimed at developig the holistic development of the learners’ personality, making them intellectually excellent,  morally upright & socially committed.
                    </p>
                    {{--<ul>
                        <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequa</li>
                        <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit</li>
                        <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in</li>
                    </ul>--}}
                    <p>
                        To objectify the subjective feelings & to materialize the penchant obsession & vaulting ambition of his own late captain Dr. Mukteswar Mohapatra, the 1st Secretary of this institute an erudite personality in the region of Kuamara, along with Er. Birendra Nath Jena, the then Secretary, Saraswata (Junior) Mahavidyalaya, Late Pradeep Ku. Mohapatra, the then President, Saraswata  Junior Mahavidyalaya, & Mr. Gopinath Panda, Principal I/c Saraswata (Jr.) Mahavidyalaya, Kuamara, Mbj. attempted to bring this institute into it real ontology implementing their sedulous efforts and industries & with the active participation of all the well-wishers of the then undivided G.P. of Kuamara & the well-wishers of adjacent regions of Kuamara, Mayurbhanj as a whole.
                    </p>

                </div>
                <div class="col-lg-12">
                    <p>
                        With the passage of time, the college got its seat strength extended from 128 to 192 in +3 Arts Stream in the session 1993 and it was made easy due to the heavy craze and demand of the public in general and indomitable desires of the countless students in particular. However, because of this intense desire of the public, last year i.e. in the year 2018, the Stream of +3 Science got Permission with a seat strength  of 80 in total (Physical Science - 48 & Biological Science - 32) having a permitted seat strength of 16 in each honours subject (Physics, Chemistry, Math, Botany & Zoology) and a total No. of 17 Staff members (Teaching  - 13 & Non-Teaching -04 Nos.)
                    </p>
                    <p>
                        Having its existence in the G.B. Nagar Block & 52 Kms. away from the district Headquarter, Baripada and 22 Kms. away from Kaptipada Sub-Division, Udala, the college “ Saraswata Snataka (Degree) Mahavidyalaya” has been running at a high pace with honours in 06 nos of Arts subjects having a permitted seat strength of 32 each in History, Pol.Sc., Philosophy, and 36 seats each in Odia, Sanskrit and 24 seats in Economics and total no. of  27 staff members (Teaching -14 and Non-Teaching 13) both teaching and non-teaching staff members as a whole. Getting utmost support from the public, now the institute is running with 2(f) and 12(B) UGC recognition under UGC Act, 1956.
                    </p>
                </div>
            </div>

        </div>
    </section><!-- End About Section -->

@include("shared.principal")

    <!-- ======= Our Skills Section ======= -->
    <section id="skills" class="skills">
        <div class="container">

            <div class="section-title">
                <h2>Our Success Rate</h2>
                <p>Check our Our Success Rate</p>
            </div>

            <div class="row skills-content">
                @foreach($data['department'] as $s)

                <div class="col-lg-6">
                    @foreach($s->department as $d)
                    <div class="progress">
                        <span class="skill">{{$d->department}} <i class="val">{{$d->success_rate}}%</i></span>
                        <div class="progress-bar-wrap">
                            <div class="progress-bar" role="progressbar" aria-valuenow="{{$d->success_rate}}" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>

                   {{-- <div class="progress">
                        <span class="skill">CSS <i class="val">90%</i></span>
                        <div class="progress-bar-wrap">
                            <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>

                    <div class="progress">
                        <span class="skill">JavaScript <i class="val">75%</i></span>
                        <div class="progress-bar-wrap">
                            <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>--}}
                    @endforeach
                </div>
                @endforeach
               {{-- <div class="col-lg-6">

                    <div class="progress">
                        <span class="skill">PHP <i class="val">80%</i></span>
                        <div class="progress-bar-wrap">
                            <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>

                    <div class="progress">
                        <span class="skill">WordPress/CMS <i class="val">90%</i></span>
                        <div class="progress-bar-wrap">
                            <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>

                    <div class="progress">
                        <span class="skill">Photoshop <i class="val">55%</i></span>
                        <div class="progress-bar-wrap">
                            <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>

                </div>--}}

            </div>

        </div>
    </section><!-- End Our Skills Section -->
@endsection
