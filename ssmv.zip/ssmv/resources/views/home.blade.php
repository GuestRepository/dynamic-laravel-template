@extends("layout.master")
@section('content')

@include("shared.slider")

    <main id="main">

        <!-- ======= About Section ======= -->
        <section id="about" class="about">
            <div class="container">

                <div class="row content">
                    <div class="col-lg-6">
                        <img src="{{asset('assets/img/principal.png')}}" style="width:100%">
                    </div>
                    <div class="col-lg-6 pt-4 pt-lg-0">
                        <div style="text-align: center">
                            <img src="{{asset("assets/img/logo.png")}}" style=" width: 200px;">
                        </div>

                        <p>
                            The college has its Emblem in the shape of a circle which drastically exhibits and ratifies
                            the meaning of its cherished ideals through symbols & this Emblem becomes the basis of the
                            very institution. The “Dancing Peacock” is a vindication to the justification of title to the
                            District as it was once ruled by the “Mayur” & the  “Bhanj” dynasties. Its believed that the
                            dance of the peacock drags monsoon to earth which is ultimately a propitious sign for
                            cultivation & good harvest what is made reflected through the cluster of paddies with stalks.
                            The forest in the Emblem justifies the existence of the institute in a foreset  abounded district
                            impregnated with natural beauties. And the “Open Book” in the middle explicitly indicates nothing
                            but unquenchable spirit for learning, herald of the light of wisdom, knowledge & enlightenment
                            as well as for the dispel of darkness & ignorance.
                        </p>

                    </div>
                </div>

            </div>
        </section><!-- End About Section -->

        <!-- ======= Clients Section ======= -->
        <section id="clients" class="clients section-bg">
            <div class="container">

                <div class="row">

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/client-1.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/client-2.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/client-3.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/client-4.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/client-5.png" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
                        <img src="assets/img/clients/client-6.png" class="img-fluid" alt="">
                    </div>

                </div>

            </div>
        </section><!-- End Clients Section -->

@include("shared.department")

        <!-- ======= News Section ======= -->
        @include("shared.news_event")
        <!-- End News Section -->

    </main><!-- End #main -->

@endsection
