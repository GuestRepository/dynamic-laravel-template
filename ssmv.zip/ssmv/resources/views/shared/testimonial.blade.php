<section class="testimonial_outer">
    <div class="container">
        <div class="testimonial_content">
            <div class="title_part two">
                <h3>What Our Students Say</h3>
                <p>Words from students</p>
            </div>
            <div>
                <div class="slider_slick slick-initialized slick-slider" >
                    <div style="width: 375px; float: left" >your content</div>
                    <div style="width: 375px; float: left" >your content</div>
                    <div style="width: 375px; float: left" >your content</div>
                    <div style="width: 375px; float: left" >your content</div>
                    <div style="width: 375px; float: left" >your content</div>
                    <div style="width: 375px; float: left" >your content</div>

                </div>
            </div>
        </div>
    </div>
</section>


