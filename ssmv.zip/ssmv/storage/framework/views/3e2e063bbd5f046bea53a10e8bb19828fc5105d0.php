<!-- ======= Pricing Section ======= -->
<section id="pricing" class="pricing">
    <div class="container">

        <div class="row">
            <?php $__currentLoopData = $data['notice']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 <?php if($loop->index>0): ?> mt-4 mt-md-0 <?php endif; ?>" >
                <div class="box featured" >
                    <h3><?php echo e($nt->type); ?></h3>
                    
                    <div style="height:200px">
                        <ul class="marquee">
                            <?php $__currentLoopData = $nt->notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($n->notice_body); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="btn-wrap">
                        <a href="#" class="btn-buy">View More</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            

        </div>

    </div>
</section><!-- End Pricing Section -->
<?php /**PATH D:\project\laravel\ssmv\resources\views/shared/news_event.blade.php ENDPATH**/ ?>