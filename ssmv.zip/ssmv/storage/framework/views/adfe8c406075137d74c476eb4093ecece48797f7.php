<!-- ======= Services Section ======= -->
<section id="services" class="services">
    <?php $__currentLoopData = $data['department']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="section-title">
                <h2>Courses</h2>
                <p>Our <?php echo e($s->stream); ?> Department</p>
            </div>
            <div class="row">
                <?php $__currentLoopData = $s->department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 <?php if($loop->index > 0): ?> mt-4 mt-md-0 <?php endif; ?>" >
                        <div class="icon-box">
                            <i class="bi bi-brightness-high"></i>
                            <h4><a href="#"><?php echo e($d->department); ?></a></h4>
                            <p><?php echo e($d->description); ?></p>
                            <h4><a href="#">Strength : <?php echo e($d->strength); ?></a></h4>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section><!-- End Services Section -->
<?php /**PATH D:\project\laravel\ssmv\resources\views/shared/department.blade.php ENDPATH**/ ?>