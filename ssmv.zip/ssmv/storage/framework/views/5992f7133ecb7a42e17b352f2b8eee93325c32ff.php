<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
    <div class="container">

        <div class="d-flex justify-content-between align-items-center">
            <h2><?php echo e(ucfirst(Request::segment(1))); ?></h2>
            <ol>
                <li><a href="<?php echo e(url("/")); ?>">Home</a></li>
                <li><?php echo e(ucfirst(Request::segment(1))); ?></li>
            </ol>
        </div>

    </div>
</section><!-- End Breadcrumbs -->
<?php /**PATH D:\project\laravel\ssmv\resources\views/shared/breadcrumbs.blade.php ENDPATH**/ ?>