<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NoticeType extends Model
{
    use HasFactory;
    protected $table="tbl_notice_type";

    public function notice(){
        return $this->hasMany(Notice::class,"notice_type_id","id");
    }
}
