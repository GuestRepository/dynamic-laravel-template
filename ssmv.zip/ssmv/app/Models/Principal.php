<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Principal extends Model
{
    use HasFactory;

    protected $table="tbl_principals";

    public function college(){
        return $this->belongsTo(College::class,"org_id","id");
    }
}
