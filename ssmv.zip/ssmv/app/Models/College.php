<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class College extends Model
{
    use HasFactory;
    protected $table="tbl_organisation";

    public function noticeType(){
        return $this->hasMany(NoticeType::class,'id','org_id');
    } 
}
