<?php

namespace App\Http\Controllers;

use App\Models\Stream;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    protected $department;
    public function __construct(){
        $this->department=Stream::with('department')->get();
    }

    public function index(){
        $data['department']=$this->department;
        return view("departments", compact('data'));
    }
}
