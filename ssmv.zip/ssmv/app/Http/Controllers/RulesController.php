<?php

namespace App\Http\Controllers;

use App\Models\Rules;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class RulesController extends Controller
{
    protected $rules ;
    public function __construct(){
        $this->rules=Rules::all();
    }

    public function index(){
        $data['rules']=$this->rules;
        return view("rules",compact('data'));
    }
}
