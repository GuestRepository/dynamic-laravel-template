<?php

namespace App\Http\Controllers;

use App\Models\Principal;
use App\Models\Stream;
use Illuminate\Http\Request;

class AboutController extends Controller
{
    public $principal;
    public function __construct(){
        $this->principal=Principal::orderBy('id','desc')->get();
        $this->department=Stream::with('department')->get();
    }
    public function index(){
        $data['principal']=$this->principal;
        $data['department']=$this->department;
        return view("about",compact('data'));
    }
}
