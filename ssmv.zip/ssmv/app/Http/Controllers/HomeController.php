<?php

namespace App\Http\Controllers;

use App\Models\College;
use App\Models\Department;
use App\Models\NoticeType;
use App\Models\Stream;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class HomeController extends Controller
{
    protected $college;
    protected $department;
    protected $noticeType;
    protected $testimonial;
    public function __construct(){
       /* $this->college=College::find(1)->get();*/
        $this->department=Stream::with('department')->get();
        $this->testimonial=Testimonial::with("department")
            ->orderBy("id","desc")
            ->limit(15)
            ->get()
        ;
        $this->noticeType=NoticeType::with("notice")->get();

    }
    public function index(){
        /*$data['college']=$this->college;*/
        $data['department']=$this->department;
        $data['testimonial']=$this->testimonial;
        $data['notice']=$this->noticeType;
        $path=public_path("assets/img/slide");
        $files=scandir($path);
        $data['slides']=$files;
        return view("home", compact('data'));
    }
}
